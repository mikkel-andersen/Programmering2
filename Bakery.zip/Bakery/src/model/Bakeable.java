package model;

public interface Bakeable {

    boolean isBaked();

    void bake();
}
